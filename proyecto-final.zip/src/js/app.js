import './router'

$(document).ready(function() {
  console.log('ready..console.')
})